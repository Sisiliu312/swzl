<template>
<body>
  <div id="app">
    <router-view/>
  </div>

</body>
</template>

<script>
export default {
		name: 'app'
	}
</script>

<style lang="css" scoped>
body{
  margin: 0px;
}
</style>
